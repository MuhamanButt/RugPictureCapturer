"use client";
import { useEffect, useRef, useState } from "react";

export default function CameraCapture() {
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [imageData, setImageData] = useState<string | null>(null);

  useEffect(() => {
    const startCamera = async () => {
      try {
        const stream = await navigator.mediaDevices.getUserMedia({ video: true });
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
        }
      } catch (error) {
        console.error("Camera access error:", error);
        alert("Camera access denied or not supported.");
      }
    };
    startCamera();
  }, []);

  const handleCapture = () => {
    const video = videoRef.current;
    const canvas = canvasRef.current;

    if (!video || !canvas) return;

    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    ctx.drawImage(video, 0, 0);
    const image = canvas.toDataURL("image/jpeg");
    setImageData(image);
    console.log("Captured image:", image); // For debugging
  };

  return (
    <div style={{ padding: "20px", textAlign: "center" }}>
      <h2>Camera Capture</h2>
      <video
        ref={videoRef}
        autoPlay
        playsInline
        style={{ width: "100%", maxWidth: "500px", border: "1px solid #ccc" }}
      />
      <br />
      <button onClick={handleCapture} style={{ marginTop: "10px", padding: "10px 20px" }}>
        Capture
      </button>
      <canvas ref={canvasRef} style={{ display: "none" }} />
      {imageData && (
        <>
          <h3>Preview</h3>
          <img src={imageData} alt="Captured" style={{ width: "100%", maxWidth: "500px" }} />
        </>
      )}
    </div>
  );
}
