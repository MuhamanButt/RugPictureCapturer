import React from 'react'
import CameraCapture from './cam'
const page = () => {
  return (
    <div><CameraCapture/></div>
  )
}

export default page